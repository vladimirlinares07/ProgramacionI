class Generador:
    def generaTabla(self, tabla):
        codigo = ""
        for t in tabla:
            codigo = codigo + "<tr>"
            for j in t.split(","):
                if j == 'Oro':
                    j= '<img src="static/img/Oro.jpg" width="50px" heigth="50px">'
                elif j== 'Plata':
                    j = '<img src="static/img/Plata.jpg" width="50px" heigth="50px">'
                elif j== 'Bronce':
                    j = '<img src="static/img/Bronce.jpg" width="50px" heigth="50px">'
                elif j== 'Cobre':
                    j = '<img src="static/img/Cobre.jpg" width="50px" heigth="50px">'
                if j == '1':
                    j= '<img src="static/img/Rugal.jpg" width="50px" heigth="50px">'
                elif j== '2':
                    j = '<img src="static/img/Winer.jpg" width="50px" heigth="50px">'
                elif j == '3':
                    j = '<img src="static/img/Alexcremento.jpg" width="50px" heigth="50px">'
                elif j== '4':
                    j = '<img src="static/img/Robert.jpg" width="50px" heigth="50px">'
                elif j== '5':
                    j = '<img src="static/img/Terry.jpg" width="50px" heigth="50px">'
                elif j== '6':
                    j = '<img src="static/img/Katy.jpg" width="50px" heigth="50px">'
                elif j== '7':
                    j = '<img src="static/img/Plinio.jpg" width="50px" heigth="50px">'
                elif j== '8':
                    j = '<img src="static/img/Diana.jpg" width="50px" heigth="50px">'
                elif j== '9':
                    j = '<img src="static/img/Killer.jpg" width="50px" heigth="50px">'
                elif j== '10':
                    j = '<img src="static/img/Oto.jpg" width="50px" heigth="50px">'
                elif j== '11':
                    j = '<img src="static/img/Macfly.jpg" width="50px" heigth="50px">'
                codigo = codigo + "<td>" + j + "</td>"
            codigo = codigo + "</tr>"
        codigo = "<table>" + codigo + "</table>"

        return codigo

    def generarTituloParrafo(self, titulo, parrafo):
        titulo = "<h1 >" + titulo + "</h1>"
        parrafo = "<p>" + parrafo + "</p>"
        return titulo + parrafo






